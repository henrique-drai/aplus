package application;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import facade.dto.ProductDTO;
import facade.dto.SaleDTO;
import facade.dto.SaleProductDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.ISaleServiceRemote;
import handlers.AddProductSaleHandler;
import handlers.CalcSaleDiscountHandler;
import handlers.CloseSaleHandler;
import handlers.GetProductByCodHandler;
import handlers.GetSaleProductsHandler;
import handlers.NewSaleHandler;

@Stateless 
public class SaleService implements ISaleServiceRemote {

	@EJB
	private NewSaleHandler newSaleHandler;
	
	@EJB
	private AddProductSaleHandler addProductHandler;
	
	@EJB private GetProductByCodHandler getProductByCodHandler;
	
	@EJB private GetSaleProductsHandler getSaleProductsHandler;
	
	@EJB private CloseSaleHandler closeSaleHandler;
	
	@EJB private CalcSaleDiscountHandler calcSaleDiscountHandler;

	@Override
	public SaleDTO newSale(int vat) throws ApplicationException {
		return newSaleHandler.newSale(vat);
	}
	
	@Override
	public SaleProductDTO addProductSale(int saleid, int prodCod, int qty) throws ApplicationException {
		return addProductHandler.addProductSale(saleid, prodCod, qty);
	}

	@Override
	public ProductDTO getProductByCod(int prodCod) throws ApplicationException {
		return getProductByCodHandler.getProduct(prodCod);
	}

	@Override
	public Iterable<SaleProductDTO> getSaleProducts(int saleId) throws ApplicationException {
		return getSaleProductsHandler.getSaleProducts(saleId);
	}

	@Override
	public void closeSale(int saleId) throws ApplicationException {
		closeSaleHandler.closeSale(saleId);
		
	}

	@Override
	public double calcSaleDiscount(int saleId) throws ApplicationException {
		return calcSaleDiscountHandler.calcSaleDiscount(saleId);
	}

}
