package catalogs;

import java.time.LocalDate;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import business.Customer;
import business.Sale;
import facade.exceptions.ApplicationException;

@Stateless
public class SaleCatalog {
	
	/**
	 * Entity manager for accessing the persistence service 
	 */
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * The customer's catalog
	 */
	@EJB
	private CustomerCatalog customerCatalog;
	
	@SuppressWarnings("unused")
	private int currentSale;
	
	@EJB
	private ProductCatalog productCatalog;
	
	/**
	 * Creates new sale
	 * 
	 * @param vat The VAT number of the customer for this sale
	 * @return The newly created Sale object 
	 * @throws ApplicationException When the customer with the vat number is not found 
	 *         or the sale could not be creaetd.
	 */
	@Transactional(Transactional.TxType.REQUIRES_NEW)
	public Sale newSale (int vat) throws ApplicationException {
		Customer customer = customerCatalog.getCustomer(vat);
		
		Sale sale = new Sale(LocalDate.now(), customer);
		currentSale = sale.getId();
		em.persist(sale);
		return sale;
	}
	
	public Sale getSaleById(int id) throws ApplicationException {
		Sale c = em.find(Sale.class, id);
		if (c == null)
			throw new ApplicationException("Sale with id " + id + " not found");
		else
			return c;
	}
	
	public Sale getCurrentSale() throws ApplicationException {
		return getSaleById(this.currentSale);
	}

}
