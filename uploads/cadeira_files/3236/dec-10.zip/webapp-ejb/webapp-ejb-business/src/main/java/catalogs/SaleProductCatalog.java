package catalogs;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import business.SaleProduct;
import facade.exceptions.ApplicationException;

@Stateless
public class SaleProductCatalog {
	
	@PersistenceContext
	private EntityManager em;
	
	public SaleProduct getSaleProductById (int id) throws ApplicationException {
		TypedQuery<SaleProduct> query = em.createNamedQuery(SaleProduct.FIND_BY_ID, SaleProduct.class);
		query.setParameter(SaleProduct.ID_NUMBER, id);
		try {
			return query.getSingleResult();
		} catch (PersistenceException e) {
			throw new ApplicationException ("SaleProduct not found.");
		}
	}

}
