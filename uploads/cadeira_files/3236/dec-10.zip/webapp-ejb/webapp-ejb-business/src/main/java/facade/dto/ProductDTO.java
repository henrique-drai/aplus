package facade.dto;

import java.io.Serializable;

public class ProductDTO implements Serializable {
	
	private static final long serialVersionUID = 8689480809777606814L;
	private final int id;
	private final String description;
	private final boolean discountEligibility;
	private final double faceValue;
	private final int prodCod;
	private final double qty;
	@SuppressWarnings("unused")
	private final int version = 0;
	@SuppressWarnings("unused")
	private final int unit_id = 0;

	
	public ProductDTO(int id, String description, boolean discountEligibility,
			double faceValue, int prodCod, double qty) {
		this.id = id;
		this.description = description;
		this.discountEligibility = discountEligibility;
		this.faceValue = faceValue;
		this.prodCod = prodCod;
		this.qty = qty;
	}


	public int getId() {
		return id;
	}


	public String getDescription() {
		return description;
	}


	public boolean getDiscountEligibility() {
		return discountEligibility;
	}


	public double getFaceValue() {
		return faceValue;
	}


	public int getProdCod() {
		return prodCod;
	}


	public double getQty() {
		return qty;
	}
	
	
	
}
