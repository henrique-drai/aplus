package facade.handlers;

import javax.ejb.Remote;

import facade.dto.ProductDTO;
import facade.dto.SaleDTO;
import facade.dto.SaleProductDTO;
import facade.exceptions.ApplicationException;

@Remote
public interface ISaleServiceRemote {
	
	public SaleDTO newSale (int vat) throws ApplicationException;
	
	SaleProductDTO addProductSale(int saleid, int prodCode, int qty) throws ApplicationException;
	
	ProductDTO getProductByCod(int prodCode) throws ApplicationException;

	Iterable<SaleProductDTO> getSaleProducts(int saleId) throws ApplicationException;

	void closeSale(int saleId) throws ApplicationException;
	
	double calcSaleDiscount(int saleId) throws ApplicationException;
}
