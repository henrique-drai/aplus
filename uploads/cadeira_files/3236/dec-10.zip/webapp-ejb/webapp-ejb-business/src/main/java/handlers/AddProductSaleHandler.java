package handlers;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import business.Product;
import catalogs.ProductCatalog;
import catalogs.SaleCatalog;
import facade.dto.SaleProductDTO;
import facade.exceptions.ApplicationException;

@Stateless
public class AddProductSaleHandler {

	@EJB
	private SaleCatalog saleCatalog;
	
	@EJB
	private ProductCatalog productCatalog;
	
	public SaleProductDTO addProductSale(int saleid, int prodCode, int qty) throws ApplicationException {
		Product product = productCatalog.getProduct(prodCode);
		try {
			saleCatalog.getSaleById(saleid).addProductToSale(product, qty);
			return new SaleProductDTO(product.getDescription(), qty);
		} catch (Exception e) {
			throw new ApplicationException ("Error adding product, ", e);
		}
	}
}
