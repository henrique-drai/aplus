package handlers;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import business.Sale;
import catalogs.ProductCatalog;
import catalogs.SaleCatalog;
import facade.exceptions.ApplicationException;

@Stateless
public class CalcSaleDiscountHandler {
	
	@EJB
	private SaleCatalog saleCatalog;
	
	@EJB
	private ProductCatalog productCatalog;
	
	public double calcSaleDiscount(int saleId) throws ApplicationException {
		try {
			Sale sale = saleCatalog.getSaleById(saleId);
			return sale.discount();
		} catch (Exception e) {
			throw new ApplicationException ("Error calculating sale discount, ", e);
		}
	}

}
