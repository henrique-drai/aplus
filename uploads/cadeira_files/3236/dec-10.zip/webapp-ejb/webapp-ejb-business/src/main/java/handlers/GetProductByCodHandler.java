package handlers;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import business.Product;
import catalogs.ProductCatalog;
import facade.dto.ProductDTO;
import facade.exceptions.ApplicationException;

@Stateless
public class GetProductByCodHandler {
	
	@EJB private ProductCatalog productCatalog;
	
	public ProductDTO getProduct(int prodCod) throws ApplicationException{
		
		try {
			Product product = productCatalog.getProduct(prodCod);
			return new ProductDTO(product.getId(),
					product.getDescription(), product.isEligibleForDiscount(),
					product.getFaceValue(), product.getProdCod(),
					product.getQty()); 
		} catch (Exception e) {
			throw new ApplicationException ("Error getting product with code " + prodCod, e);
		}
	}

}
