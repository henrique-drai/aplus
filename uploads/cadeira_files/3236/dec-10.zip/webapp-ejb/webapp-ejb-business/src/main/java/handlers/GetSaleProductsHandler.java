package handlers;

import java.util.LinkedList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import business.Sale;
import business.SaleProduct;
import catalogs.SaleCatalog;
import catalogs.SaleProductCatalog;
import facade.dto.SaleProductDTO;
import facade.exceptions.ApplicationException;

@Stateless
public class GetSaleProductsHandler {
	/**
	 * The customer's catalog
	 */
	@EJB
	private SaleProductCatalog saleProductCatalog;
	
	@EJB
	private SaleCatalog saleCatalog;
	
	
	public SaleProductDTO getSaleProduct(int id) throws ApplicationException {
		
		try {
			SaleProduct saleProduct = saleProductCatalog.getSaleProductById(id);
			return new SaleProductDTO(saleProduct.getProduct().getDescription(), saleProduct.getQty());
		} catch (Exception e) {
			throw new ApplicationException ("Error getting customer with id " + id, e);
		}
	}

	public List<SaleProductDTO> getSaleProducts(int saleId) throws ApplicationException {
		
		try {
			Sale sale = saleCatalog.getSaleById(saleId);
			List<SaleProduct> saleProducts = sale.getSaleProducts();
			List<SaleProductDTO> allSaleProducts = new LinkedList<>();
			for (SaleProduct sp : saleProducts)
				allSaleProducts.add(new SaleProductDTO(sp.getProduct().getDescription(), sp.getQty()));
			return allSaleProducts;			
		} catch (Exception e) {
			throw new ApplicationException ("Error getting all sale products", e);
		}  
	}
}
