package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facade.exceptions.ApplicationException;
import facade.handlers.ISaleServiceRemote;
import presentation.web.model.AllProductsModel;

@Stateless
public class AllSaleProductsAction extends Action {
	
	@EJB
	private ISaleServiceRemote allSaleProductsHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		/*
		 * if(request.getParameter("saleId") != "") { try {
		 * allSaleProductsHandler.getSaleProducts(intValue(request.getParameter("saleId"
		 * )));
		 * request.getRequestDispatcher("/getAllSaleProducts/showAllSaleProducts.jsp").
		 * forward(request, response); } catch (ApplicationException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } }
		 */
	
		
		AllProductsModel model = new AllProductsModel();
		createHelper(model, request);
		
		if (validInput(model)) {
			try {
				allSaleProductsHandler.getSaleProducts(intValue(model.getId()));
				//model.clearFields();
			} catch (ApplicationException e) {
				model.addMessage("Error searching SaleProduct: " + e.getMessage());
			}
			request.setAttribute("model", model);
			model.addMessage("sale product successfully requested.");
		} else
			model.addMessage("Error validating sale product data");
		
		request.getRequestDispatcher("/getAllSaleProducts/showAllSaleProducts.jsp").forward(request, response);
	}

	
	
	  private boolean validInput(AllProductsModel model) {
	  
		  	// check if designation is filled
			boolean result = isFilled(model, model.getId(), "Sale id must be filled.");
			
			return result;
	  }
	  
	  
	  private AllProductsModel createHelper(AllProductsModel model, HttpServletRequest request) { // Create
			// Create the object model
			model.setAddSaleProductsHandler(allSaleProductsHandler);

			// fill it with data from the request
			model.setId(request.getParameter("saleId"));
			
			return model;
	  }
	 

}
