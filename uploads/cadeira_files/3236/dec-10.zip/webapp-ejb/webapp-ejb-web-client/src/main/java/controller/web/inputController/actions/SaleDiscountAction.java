package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import presentation.web.model.SaleDiscountModel;

@Stateless
public class SaleDiscountAction extends Action {

	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SaleDiscountModel model = new SaleDiscountModel();		
		request.setAttribute("model", model);		
		request.getRequestDispatcher("/saleDiscount/saleDiscount.jsp").forward(request, response);
		
	}
}
