package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facade.dto.SaleDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.ISaleServiceRemote;
import presentation.web.model.CloseSaleModel;
import presentation.web.model.NewSaleModel;

@Stateless
public class ShowClosedSaleAction extends Action {
	@EJB 
	private ISaleServiceRemote closeSaleHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		CloseSaleModel model = new CloseSaleModel();
		model.setId(request.getParameter("saleId"));
		// the other data, date and status will be created by the handler

		if (validInput(model)) {
			try {
				
				closeSaleHandler.closeSale(intValue(model.getId()));
				
				request.setAttribute("model", model);
				//model.clearFields();
				model.addMessage("Sale successfully closed.");
			} catch (ApplicationException e) {
				model.addMessage("Error closing sale: " + e.getMessage());
			}
		} else
			model.addMessage("Error validating sale data");
		
		request.getRequestDispatcher("/closeSale/showClosedSale.jsp").forward(request, response);

		
	}
	
	private boolean validInput(CloseSaleModel model) {
		
		// check if designation is filled
		boolean result =  isFilled(model, model.getId(), "id number must be filled");
		
		return result;
	}
}
