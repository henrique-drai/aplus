package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facade.exceptions.ApplicationException;
import facade.handlers.ISaleServiceRemote;
import presentation.web.model.AddProductModel;

@Stateless
public class ShowProductSaleAction extends Action {

	@EJB
	private ISaleServiceRemote addProductSaleHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AddProductModel model = new AddProductModel();
		model.setSaleId(request.getParameter("saleId"));
		model.setProdCode(request.getParameter("prodCode"));
		model.setQty(request.getParameter("qty"));
		
		if(validInput(model)) {
			populateHelper(model, request);
			
			try {
				addProductSaleHandler.addProductSale(intValue(model.getSaleId()), intValue(model.getprodCode()), intValue(model.getQty()));
			} catch (ApplicationException e) {
				e.printStackTrace();
			}
			
			request.setAttribute("model", model);
			model.addMessage("Product successfully added to the sale.");
		} else {
			model.addMessage("Error validating product data");
		}
		
		request.getRequestDispatcher("/addProductSale/showProductsSale.jsp").forward(request, response);
	}
	
	private boolean validInput(AddProductModel model) {
		boolean result =  isFilled(model, model.getprodCode(), "prodCode must be filled")
			       && isInt(model, model.getprodCode(), "prodCode with invalid characters")
			       && isFilled(model, model.getQty(), "qty must be filled")
			       && isInt(model, model.getQty(), "qty with invalid characters")
			       && isFilled(model, model.getSaleId(), "saleId must be filled")
			       && isInt(model, model.getSaleId(), "saleId with invalid characters");
		return result;
	}
	
	private void populateHelper(AddProductModel model, HttpServletRequest request) {

		// fill it with data from the request
		model.setSaleId(request.getParameter("saleId"));
		model.setProdCode(request.getParameter("prodCode"));
		model.setQty(request.getParameter("qty"));
	}
}
