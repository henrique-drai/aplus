package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facade.exceptions.ApplicationException;
import facade.handlers.ISaleServiceRemote;
import presentation.web.model.SaleDiscountModel;

@Stateless
public class ShowSaleDiscountAction extends Action {
	
	@EJB
	private ISaleServiceRemote calculateSaleDiscountHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SaleDiscountModel model = new SaleDiscountModel();
		model.setId(request.getParameter("saleId"));
		
		if(validInput(model)) {
			
			try {
				model.setDiscount(Double.toString(calculateSaleDiscountHandler.calcSaleDiscount(intValue(model.getId()))));
			} catch (ApplicationException e) {
				e.printStackTrace();
			}
			
			request.setAttribute("model", model);
			model.addMessage("Discount successfully calculated.");
		} else {
			model.addMessage("Error validating sale data");
		}
		
		request.getRequestDispatcher("/saleDiscount/showSaleDiscount.jsp").forward(request, response);
	}
	
	private boolean validInput(SaleDiscountModel model) {
		boolean result =  isFilled(model, model.getId(), "id must be filled");
		
		return result;
	}
}
