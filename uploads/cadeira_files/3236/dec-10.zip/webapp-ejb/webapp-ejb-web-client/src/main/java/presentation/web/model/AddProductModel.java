package presentation.web.model;

import facade.handlers.ISaleServiceRemote;

public class AddProductModel extends Model {

	private static final long serialVersionUID = 4920294965851745695L;
	private String saleId;
	private String prodCode;
	private String qty;
	@SuppressWarnings("unused")
	private ISaleServiceRemote addProductSaleHandler;
	
	public void setAddProductSaleHandler(ISaleServiceRemote addProductHandler) {
		this.addProductSaleHandler = addProductHandler;
	}
	
	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	
	public String getSaleId() {
		return saleId;
	}
	
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;	
	}
	
	public String getprodCode() {
		return prodCode;
	}
	
	public void setQty(String qty) {
		this.qty = qty;	
	}
	
	public String getQty() {
		return qty;
	}
	
	public void clearFields() {
		qty =  "";
		prodCode = "";
	}
}
