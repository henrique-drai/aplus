package presentation.web.model;


import java.util.LinkedList;

import facade.dto.SaleProductDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.ISaleServiceRemote;

public class AllProductsModel extends Model {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6903623409276691463L;
	private ISaleServiceRemote addSaleHandler;
	private String id;

	public void setAddSaleProductsHandler(ISaleServiceRemote addSaleHandler) {
		this.addSaleHandler = addSaleHandler;
	}
	
	public Iterable<SaleProductDTO> getSaleProducts() throws ApplicationException {
		try {
			System.out.println(id);
			return addSaleHandler.getSaleProducts(Integer.parseInt(this.id));
		} catch (ApplicationException e) {
			return new LinkedList<> ();		
		}	
	}
	
	public String getId() {
		return this.id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public void clearFields() {
		id =  "";
	}

}
