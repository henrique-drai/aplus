package presentation.web.model;

import facade.handlers.ISaleServiceRemote;

public class CloseSaleModel extends Model {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5724957450881996999L;
	private ISaleServiceRemote closeSaleHandler;
	private String id;
	private String status;

	public void setCloseSaleHandler(ISaleServiceRemote closeSaleHandler) {
		this.closeSaleHandler = closeSaleHandler;
	}
	
	public String getId() {
		return this.id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getStatus() {
		return this.status;
	}
	
	public void setStatus(String id) {
		this.id = status;
	}
	
	public void clearFields() {
		id =  "";
	}
}
