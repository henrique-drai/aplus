package presentation.web.model;

public class SaleDiscountModel extends Model {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8349890070674774189L;
	private String id;
	private String discount;
		
	
	public void setDiscount(String discount) {
		this.discount = discount;	
	}
	
	public String getDiscount() {
		return discount;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public void clearFields() {
		id = discount = "";
	}
	
}
