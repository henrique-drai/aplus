$(document).ready(function () {
    var iter = '0';
    localStorage.setItem("iter", iter);
    var available = false;

    
    $("#proj_save").click(function() {
        if ($("input[name=proj_name]").val() != '' && $("input[name=proj_members]").val() != '') {
            if (localStorage.getItem("newiter") == null) {
                var k = parseInt(localStorage.getItem("iter"));
                available = true;
            } else {
                event.preventDefault();
                var k = parseInt(localStorage.getItem("newiter"));
                for(var i=0; i<=k; i++) {
                    if ($("input[name=proj_name]").val() == localStorage.getItem("proj_name"+i)) {
                        available = false;
                        $("#proj_err").css("display", "block");
                        break;
                    } else {
                        available = true;
                    }
                }
            }  
    
            if (available) {
                $("#empty_forms").hide();
                $("#proj_err").hide();
                submit(k);
                return true;
            } else {
                $("#empty_forms").hide();
                $("#proj_err").show();
                return false;
            }
        } else {
            $("#proj_err").hide();
            $("#empty_forms").show();
        }
        
    });

    //on click events index.html
    $("#newProject").click(function(){
        window.location.href="new_proj.html";
    });

    $("#myProjects").click(function(){
        window.location.href="projects.html";
    });

});

function submit(index) {
    localStorage.setItem("proj_name"+index, $("input[name=proj_name]").val());  
    localStorage.setItem("proj_tar"+index, '');
    localStorage.setItem("proj_members"+index, $("input[name=proj_members]").val());
    localStorage.setItem("newiter", index+1);
    localStorage.setItem("finished_tar"+index,'');
    $("#success").fadeIn();

    setTimeout(function(){
        $("#success").fadeOut();
        window.location.href="projects.html";
        }, 2500);
}