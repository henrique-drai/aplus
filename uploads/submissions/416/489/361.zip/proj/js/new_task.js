$(document).ready(function () {
    for(var i=0; i<localStorage.getItem("newiter"); i++) {
        var project = localStorage.getItem("proj_name"+i);
        $("#proj_select").append("<option value='"+project+"'>"+project+"</option>");
    }

    $("#proj_select").on("change", function() {
        $("#members_select option").remove();
        for(var i=0; i<localStorage.getItem("newiter"); i++) {
            if($("#proj_select").val() == localStorage.getItem("proj_name"+i)) {
                //handle string ;
                var member = localStorage.getItem("proj_members"+i);
                var member2 = member.split(";");
                for (var j=0; j<member2.length; j++){
                    $("#members_select").append("<option value='"+member2[j]+"'>"+member2[j]+"</option>");
                }
            }
        }
    });

    //adicionar tarefas ao proj_tar respetivo do projeto selecionado. 
    $("#new_tarefa").click(function(){
        var project_sel = $("#proj_select").val();
        var member_sel = $("#members_select").val();
        var tarefa_descr = $("input[name=nova_tarefa]").val();
        var success = false;


        if (project_sel != '' && member_sel != '' && tarefa_descr != ''){
            for (var i=0; i<localStorage.getItem("newiter"); i++){
                if (localStorage.getItem("proj_name"+i) == project_sel){
                    var projid = i;
                }
            }

            var tarefas = [[]];
            var tarefasLocal = localStorage.getItem("proj_tar"+projid);
            if (tarefasLocal != ''){
                var new_tarefas = JSON.parse(tarefasLocal);
                var index = new_tarefas.lenght-1;
                var exists = false;
                for (var i=0; i<new_tarefas.length; i++){
                    if (new_tarefas[i][0] == member_sel){
                        index = i;
                        exists = true;
                    }
                }
                
                if(exists){
                    //Verify if the new task already exists
                    var tarefa_exists = false;
                    for (var i=0; i<new_tarefas[index].length; i++){
                        if (new_tarefas[index][i] == tarefa_descr){
                            tarefa_exists = true;
                        }
                    }
                
                    if (tarefa_exists){
                        success = false;
                    } else {
                        new_tarefas[index].push(tarefa_descr);
                        success = true;
                    }
                } else {
                    new_tarefas.push([member_sel,tarefa_descr]);
                    success = true;
                }

                localStorage.setItem("proj_tar"+projid, JSON.stringify(new_tarefas));
            } else {
                tarefas[0].push(member_sel);
                tarefas[0].push(tarefa_descr);
                localStorage.setItem("proj_tar"+projid, JSON.stringify(tarefas));
                success = true;
            }
        
            if (success){
                $("#val_suc").fadeIn();

                setTimeout(function(){
                    $("#val_suc").fadeOut(); 
                    window.location.href="projects.html";
                    }, 2500);  
            } else {
                $("#val_error2").fadeIn();

                setTimeout(function(){
                    $("#val_error2").fadeOut(); 
                    }, 3000);  
            }

        }else{
            $("#val_error").fadeIn();

            setTimeout(function(){ 
                $("#val_error").fadeOut();
             }, 3000);
        }
    });

});