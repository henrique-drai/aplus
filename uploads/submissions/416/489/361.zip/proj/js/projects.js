$(document).ready(function () {

    for (var i = 0; i < localStorage.getItem("newiter"); i++){
        var projname = localStorage.getItem("proj_name"+i);
        var projmemb = localStorage.getItem("proj_members"+i);
        var projtar = localStorage.getItem("proj_tar"+i)
        $("#projetos").append("<tr><td>" +projname+ "</td><td>" + projmemb + "</td><td>" + projtar + "</td></tr>");
    }

});