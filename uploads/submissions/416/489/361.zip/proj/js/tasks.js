$(document).ready(function () {
    var proj_tasks = [];
    var selected_proj = '';
    var selected_task = '';
    var selected_member = 0;
    var member_name = '';

    for(var i=0; i<localStorage.getItem("newiter"); i++) {
        var project = localStorage.getItem("proj_name"+i);
        $("#proj_select").append("<option value='"+project+"'>"+project+"</option>");
    }

    $("#proj_select").on("change", function() {
        $("#tarefas tr").remove();
        $("#tarefas p").remove();
        $("#members_select option").remove();
        $("#div_sdate").hide();
        $("#div_shour").hide();
        $("#div_fdate").hide();
        $("#div_fhour").hide();
        $("#time_spent").hide();
        $("#save_tar_changes").hide();
        $("#div_tar_sel").hide();
        $("#tarefas tr").remove();
        $("#tarefas_table p").remove();

        if($("#proj_select").val() != '') {
            $("#tar_select option").remove();
            selected_proj = $("#proj_select").val();
            $("#members_select").append("<option value=''>Seleciona um membro</option>");
            for(var i=0; i<localStorage.getItem("newiter"); i++) {
                if($("#proj_select").val() == localStorage.getItem("proj_name"+i)) {
                    //handle string ;
                    var member = localStorage.getItem("proj_members"+i);
                    var member2 = member.split(";");
                    for (var j=0; j<member2.length; j++){
                        $("#members_select").append("<option value='"+member2[j]+"'>"+member2[j]+"</option>");
                    }
                }
            }

            $("#div_member").show();
        } else {
            $("#div_member").hide();
            $("#tar_select option").remove();
        }

    });

    $("#members_select").on("change", function() {
        $("#tarefas tr").remove();
        $("#tarefas p").remove();
        $("#tarefas_table p").remove();
        $("#tar_select option").remove()
        $("#div_sdate").hide();
        $("#div_shour").hide();
        $("#div_fdate").hide();
        $("#div_fhour").hide();
        $("#time_spent").hide();
        $("#save_tar_changes").hide();

        if($("#members_select").val() != '') {
            var project_sel = $("#proj_select").val();
            var member_sel = $("#members_select").val();
            $("#tarefas tr").remove();
    
            if(project_sel != '' && member_sel != '') {
                for(var i=0; i<localStorage.getItem("newiter"); i++) {
                    if (localStorage.getItem("proj_name"+i) == project_sel){
                        var projid = i;
                    }
                }
                
                if(localStorage.getItem("proj_tar"+projid) != '') {
                    var tasks = JSON.parse(localStorage.getItem("proj_tar"+projid));
                    proj_tasks = tasks;
                    var tasks_count = 0;
        
                    for(var i=0; i<tasks.length; i++) {
                        if(tasks[i] != '') {
                            if(tasks[i][0].includes(member_sel)) {
                                selected_member = i;
                                member_name = member_sel;
                                if(tasks[i].length > 1) {
                                    $("#tarefas").append("<tr><th id='tar_num'>Nº Tarefa</th><th id='tar_desc'>Descrição da Tarefa</th></tr>");
                                    
                                    for(var k=0; k<tasks[i].length-1; k++) {
                                        tasks_count++;
                                        $("#tarefas").append("<tr><td>" + tasks_count + "</td><td>" + tasks[i][k+1] + "</td></tr>");
                                    }
            
                                    $("#tar_select").append("<option value=''>Seleciona o Número da Tarefa</option>");
            
                                    for(var j=1; j<=tasks_count; j++) {
                                        $("#tar_select").append("<option value='" + j + "'>Tarefa " + j + "</option>");
                                    }
    
                                    $("#div_tar_sel").show();
            
                                } else if (tasks[i].length <= 1) {
                                    $("#div_tar_sel").hide();
                                    $("#tar_select option").remove();
                                    $("#tarefas_table").append("<p>" + member_sel + " não tem nenhuma tarefa por realizar.</p>");
                                }
                                break;
                                
                            } else if(tasks.length == 1) {
                                $("#div_tar_sel").hide();
                                $("#tar_select option").remove();
                                $("#tarefas_table").append("<p>" + member_sel + " não tem nenhuma tarefa por realizar.</p>");
                            }
                        } else {
                            $("#div_tar_sel").hide();
                            $("#tar_select option").remove();
                            $("#tarefas_table").append("<p>" + member_sel + " não tem nenhuma tarefa por realizar.</p>");
                        }
                       
                    }
                } else {
                    $("#div_tar_sel").hide();
                    $("#tar_select option").remove();
                    $("#tarefas_table").append("<p>" + member_sel + " não tem nenhuma tarefa por realizar.</p>");
                }
                
    
            }
    
            $("#tarefas_table").show();
        } else {
            $("#div_tar_sel").hide();
            $("#div_sdate").hide();
            $("#div_shour").hide();
            $("#div_fdate").hide();
            $("#div_fhour").hide();
            $("#time_spent").hide();
            $("#save_tar_changes").hide();
        }
        
    });

    $("#tar_select").on("change", function() {
        if($("#tar_select").val() != '') {
            $("#div_sdate").show();
            $("#div_shour").hide();
            $("#div_fdate").hide();
            $("#div_fhour").hide();
            $("#time_spent").hide();
            $("#save_tar_changes").hide();

            selected_task = $("#tar_select").val();
        }
    })

    $("#start_date").on("change", function() {
        if($("#tar_select").val() != '') {
            $("#div_shour").show();
            $("#div_fdate").hide();
            $("#div_fhour").hide();
            $("#time_spent").hide();
            $("#save_tar_changes").hide();
            document.getElementById("finish_date").setAttribute("min", $("#start_date").val());
        }
    });

    $("#start_time").on("change", function() {
        if($("#tar_select").val() != '') {
            $("#div_sdate").show();
            $("#div_fdate").show();
            $("#div_fhour").hide();
            $("#time_spent").hide();
            $("#save_tar_changes").hide();
            document.getElementById("finish_time").setAttribute("min", $("#start_time").val());
        }
    })

    $("#finish_date").on("change", function() {
        if($("#tar_select").val() != '') {
            $("#div_fhour").show();
            $("#time_spent").hide();
            $("#save_tar_changes").hide();
        }
    })

    $("#finish_time").on("change", function() {        
        if($('#finish_date').val() != '' && $("#finish_time").val() != '' && $('#start_date').val() != '' && $("#start_time").val() != '' && $("#tar_select").val() != '') {

            $("#tar_time p").remove();
            var fdate = new Date($('#finish_date').val());
            var sdate = new Date($('#start_date').val());
            const diffTime = Math.abs(fdate - sdate);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));


            var ftime = new Date(0, 0, 0, $("#finish_time").val().split(":")[0], $("#finish_time").val().split(":")[1], 0);
            var stime = new Date(0, 0, 0, $("#start_time").val().split(":")[0], $("#start_time").val().split(":")[1]);

            var diff = ftime.getTime() - stime.getTime();
            var hours = Math.floor(diff / (1000 * 60 * 60));
            diff -= hours * (1000 * 60 * 60);
            var mins = Math.floor(diff / (1000 * 60));
            diff -= mins * (1000 * 60);

    
            $("#time_spent").show();
            $("#tar_time").append("<p>" + Math.abs(diffDays) + " dias " + Math.abs(hours) + " horas " + Math.abs(mins) + " minutos.</p>");
            $("#save_tar_changes").show();
        }
    });


    $("#tar_changes").click(function(){
        for(var i=0; i<localStorage.getItem("newiter"); i++) {
            if(selected_proj == localStorage.getItem("proj_name"+i)) {
                if(localStorage.getItem("finished_tar"+i) == "") {
                    tar = [];
                    tar.push([proj_tasks[selected_member][0], proj_tasks[selected_member][selected_task], $("#tar_time").text()]);
                    localStorage.setItem("finished_tar"+i, JSON.stringify(tar));
                    proj_tasks[selected_member].splice(selected_task, 1);
                    localStorage.setItem("proj_tar"+i, JSON.stringify(proj_tasks));
                    window.location.href="time_projects.html";
                } else {
                    tar = JSON.parse(localStorage.getItem("finished_tar"+i));
                    for(var j=0; j<localStorage.getItem("finished_tar"+i).length; j++) {
                        if(j==selected_member) {
                            if(proj_tasks[i][0] == member_name) {
                                tar[j].push(proj_tasks[i][selected_task], $("#tar_time").text());
                                localStorage.setItem("finished_tar"+i, JSON.stringify(tar));
                            } else {
                                console.log(tar)
                                console.log(j)
                                tar.push([proj_tasks[selected_member][0], proj_tasks[selected_member][selected_task], $("#tar_time").text()]);
                                localStorage.setItem("finished_tar"+i, JSON.stringify(tar));
                            }
                           
                        }
                    }
                    proj_tasks[selected_member].splice(selected_task, 1);
                    console.log(proj_tasks);
                    localStorage.setItem("proj_tar"+i, JSON.stringify(proj_tasks));
                    
                    window.location.href="time_projects.html";
                }
            }
        }
    });
});