$(document).ready(function () {

    for (var i = 0; i < localStorage.getItem("newiter"); i++){
        var projname = localStorage.getItem("proj_name"+i);
        if (localStorage.getItem("finished_tar"+i) != ''){
            var projfinished = JSON.parse(localStorage.getItem("finished_tar"+i));
            for (var j = 0; j < projfinished.length; j++){
                var actualmember = projfinished[j].shift();
                for(var k=0; k < projfinished[j].length; k+=2){
                    $("#tempo_projetos").append("<tr><td>" +projname+ "</td><td>" + actualmember + "</td><td>" + projfinished[j][k] + "</td><td>" + projfinished[j][k+1] + "</td></tr>");
                }
            }
        }
    }

});