<?php
	include "php_includes/openconn.php";
	ini_set('display_errors', 1);
	session_start();
	$_SESSION['query_par'] = 'ALL';
?>

<!DOCTYPE html>
<html>
	<head>
		<title>AQUAMON</title>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"/>
		<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/aquamon.css">
		<link rel="icon" href="img/aquamon-icon.png" type="image/png" sizes="16x16">
		<script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<!-- <script async src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBrbyExB6Hs2H84-DOHCPqqtIh9gtql9lg&callback=initMap"></script> -->
		<script src="js/newjs.js"></script>
		<script src="js/slide.js"></script>
		<!-- <script src="js/aquamon.js"></script> -->
		
	</head>



	<body>
		<header class="simple_header">
			<img id="header_img" src="img/header.png" alt="header">
		</header>

		<!-- No header, and the drawer stays open on larger screens (fixed drawer). -->
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer">
			<div id="drawer" class="mdl-layout__drawer">
				
				<div class="demo-list-action mdl-list">
					<div class="mdl-list__item">

						<ul id="sidebar" class="entity-list group-list mdl-list ">

							<div class="mdh-expandable-search">
								<i class="material-icons">search</i>
								<input class="mdl-textfield__input" placeholder ="Search" type="text" id="sample6">
								<label class="mdl-textfield__label" for="sample-expandable"></label>
							</div>
						</ul>
					</div>
				</div>
			</div>

			<main class="mdl-layout__content">
				<div class="mdl-grid">
					<div class="mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet">

						<div class="mdl-grid">    
							<div class="mdl-cell mdl-cell--6-col">
								<div id="realtime-chart"></div>
							</div>

							<div class="mdl-cell mdl-cell--6-col">
								<div id="map"></div>
							</div>
						</div>
					</div>
				</div>

				<div id="node_name">
				</div>
				
				<!-- <div class="mdl-grid">
					<div class="mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet">

						<div class="mdl-grid"> 
							<div class="mdl-cell mdl-cell--4-col">
								<div id="energy-chart"></div>
							</div>   
							<div class="mdl-cell mdl-cell--4-col">
								<div id="rssi-chart"></div>
							</div>
							<div class="mdl-cell mdl-cell--4-col">
								<div id="bar-chart"></div>
							</div>
						</div>  
					</div>
				</div> -->
			</main>
		</div>

	</body>
</html>
