$.getJSON( "json/new.json", function( json ) {
    var data = json.members;
    //iterar pelas networks
    for (var i = 0; i < data.length; i++){
        var network = data[i];
        var name = network.Network.Name;
        var members = network.Network.Gateway.members;
        var new_html= '<li class="mdl-list__item mdl-list__item--two-line group-item" name="group_'+i+'">'
            + '<span class="mdl-list__item-primary-content">'
            + '<span>' + name + '</span>'
            + '<span class="mdl-list__item-sub-title">' + members.length + ' devices</span>'
            + '</span>'
            + '<span class="mdl-list__item-secondary-content"></span>'
            + '</li>';
        
        $("#sidebar").append(new_html);

        //gateway - existe sempre e deve ser tratada à parte
        var gateway = network.Network.Gateway;
        var status = network.Network.Gateway.status;
        var s = verify_status(status);
        var gateway_html = '<ul class="entity-list device-list mdl-list" name="group_'+i+'">'
            + '<li class="mdl-list__item mdl-list__item--two-line" value="1" name="'+gateway.Name+'">'
            + '<span class="mdl-list__item-primary-content">'
            + '<span class="entity-name">'+ gateway.Name +'</span>'
            + '<span class="mdl-list__item-sub-title"><span class="'+s[0]+'"></span>'+s[1]+'</span>'
            + '</span>'
            + '<span class="mdl-list__item-secondary-content">'
            + '<div><div class="gateway"></div></div></span></li>';

        
        // iterar pelos restantes nodes
        var member_html = '';
        for (var j = 0; j < members.length; j++){
            var member = members[j];
            var s = verify_status(member.Node.status);
            var val = 4 + j;
            member_html += '<li class="mdl-list__item mdl-list__item--two-line" value="'+ val +'" name="'+ member.Node.Name +'">'
                + '<span class="mdl-list__item-primary-content">'
                + '<span class="entity-name">'+ member.Node.Name +'</span>'
                + '<span class="mdl-list__item-sub-title"><span class="'+s[0]+'"></span>'+s[1]+'</span>'
                + '</span>'
                + '<span class="mdl-list__item-secondary-content">'
                + '<div><div class="'+ member.Node.type +'"></div></div>'
                + '</span></li>';

        }

        $("#sidebar").append(gateway_html + member_html);
    }
});

function verify_status(status){
    if (status == "C"){
        return ["device-connected","Connected"];
    } else if (status == "I"){
        return ["device-partial-connected", "Inactive"];
    } else if (status == "D"){
        return ["device-disconnected", "Disconnected"];
    }
    
}