$(document).ready(function(){
    console.log("asd");

    var open = true;
    var snd = false;

    setInterval(function(){
		$("#node_name").load('php_includes/session_setter.php');
	}, 500) /* (0.5 seconds)*/

    $('body').on('click','#sidebar li', function(e) {
        var name = $($($(this).children()[0]).children()[0]).text();
        var group= $(this).attr('name');        
        
        $("#sidebar ul").not("ul[name='"+group+"']").slideUp("fast", function() {
            $("#sidebar li").not("li[name='"+group+"']").css("transform", "scale(1)");
            $("#sidebar li").not("li[name='"+group+"']").css("background-color", "#b0bec5");
        });
        $("ul[name='"+group+"']").slideToggle('fast', function() {
            if($("ul[name='"+group+"']").is(":visible")) {
                $("li[name='"+group+"']").css("transform", "scale(1.02)");
                $("li[name='"+group+"']").css("background-color", "rgb(120, 156, 172)");
            } else {
                $("li[name='"+group+"']").css("transform", "scale(1)");
                $("li[name='"+group+"']").css("background-color", "#b0bec5");
            
            }
            console.log($("#sidebar ul").is(":visible"))
            if($("#sidebar ul").is(":visible")) {
                search_ajax_way(name);
            } else {
                search_ajax_way("ALL");
            }
        });
        
    });
    

    function search_ajax_way(name) {
        $.ajax({
            method: "POST",
            url: "php_includes/session_setter.php",
            data: {'name': name},
            success: function(){
                console.log("deu " + name);
            }
        });
    }


})