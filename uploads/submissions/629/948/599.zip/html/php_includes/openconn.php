<?php
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "carapau2020";
    $db_name = "aquamon";

    //Cria a ligação à BD
    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    // Check connection
   
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $conn->set_charset("utf8");

?>