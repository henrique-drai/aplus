module Calculos
( PercInteresse,
 Percurso,
 Categoria,
 percToList,
 piToList,
 ganhoTotal,
 ganhoMetro,
 distanciaTotal,
 categoria,
 minutos,
 passapor,
 diminuir,
 inBetween
) where 

import Numeric --import para arredondar

data Categoria = A | B | C | D deriving Show
type PercInteresse = (Float, Float, String)
type Percurso = (Float, Float, Float, String)

percToList :: String -> [Percurso]
percToList perc = percListToFloat $ map (split ',') $ lines perc

percListToFloat :: [[String]] -> [Percurso]
percListToFloat [] = []
percListToFloat (x:rest) = (a, b, c, d) : percListToFloat rest
    where
        a = read(x!!0) :: Float 
        b = read(x!!1) :: Float
        c = read(x!!2) :: Float
        d = x!!3



piToList :: String -> [PercInteresse]
piToList pi = piListToFloat $ map (split ',') $ lines pi


piListToFloat :: [[String]] -> [PercInteresse]
piListToFloat [] = []
piListToFloat (x:rest) = (a, b, c) : piListToFloat rest
    where 
        a = read(x!!0)
        b = read(x!!1)
        c = x!!2


        
ganhoAux :: Percurso -> Percurso -> Float
ganhoAux (_,_,x1,_) (_,_,y1,_)
    | x1 < y1 = y1 - x1
    | otherwise = 0

ganhoTotal :: [Percurso] -> Float
ganhoTotal [] = 0
ganhoTotal [x] = 0
ganhoTotal (x:y:[]) = ganhoAux x y
ganhoTotal (x:y:perc) = ganhoAux x y + ganhoTotal (y:perc)

-- ganho ao metro
distAux :: Percurso -> Percurso -> Float
distAux (x1,x2,_,_) (y1,y2,_,_) = sqrt(((y1 - x1)^2 + (y2 - x2)^2))


distanciaTotal :: [Percurso] -> Float
distanciaTotal [] = 0
distanciaTotal [x] = 0
distanciaTotal (x:y:[]) = distAux x y
distanciaTotal (x:y:perc) = distAux x y + distanciaTotal (y:perc)

ganhoMetro :: [Percurso] -> String
ganhoMetro xs = Numeric.showFFloat Nothing ( diminuir ( ganhoTotal xs / (distanciaTotal xs * 85000)) 3) ""


-- categoria
categoria :: Integer -> Float -> Categoria
categoria ganho dist
    | ganho < 500 && (dist * 85000) < 10000 = A
    | ganho < 800 && (dist * 85000) < 12000 = B
    | ganho < 1500 && (dist * 85000) < 15000 = C
    | otherwise = D


-- tempo em minutos
minutos :: Percurso -> Percurso -> Float 
minutos (_,_,_,hInicio) (_,_,_,hFim) = minutosAux (split ':' hInicio) (split ':' hFim) 
    where 
        minutosAux (h:m:s:[]) (h1:m1:s1:[]) = ((read h1 - read h) * 60) + (read m1 - read m) + ((read s1 - read s) / 60)

-- funções gerais
split :: Char -> String -> [String]
split _ [] = [""]
split s (c:cs)
    | c == s  = "" : rest
    | otherwise = (c : head rest) : tail rest
    where rest = split s cs

diminuir :: Float -> Int -> Float
diminuir ponto casa = (fromIntegral $ round (ponto * 10^casa)) / (10.0^casa)

getFstPi :: PercInteresse -> Float
getFstPi (a,_,_) = a

getSndPi :: PercInteresse -> Float
getSndPi (_,b,_) = b

getLastPi :: PercInteresse -> String
getLastPi (_,_,c) = c


-- percursos
passapor :: [Percurso] -> [PercInteresse] -> [String]
passapor _ [] = []
passapor perc (pi:piList) = isVizinho perc pi ++ passapor perc piList

isVizinho :: [Percurso] -> PercInteresse -> [String]
isVizinho [] _ = []
isVizinho (p:perc) pi
    | inRaio p pi = [getLastPi pi]
    | otherwise = isVizinho perc pi

inRaio :: Percurso -> PercInteresse -> Bool
inRaio p pi = inRaioAux $ casadecimal p pi
    where inRaioAux [(p1, p2),(pi1, pi2)] = inBetween (pi1 - 1.0/10^getCasa) p1 (pi1 + 1.0/10^getCasa) && inBetween (pi2 - 1.0/10^getCasa) p2 (pi2 + 1.0/10^getCasa)
          getCasa = length (last $ split '.' $ show (getFstPi pi))

inBetween :: Float -> Float -> Float -> Bool
inBetween x y z
    | x <= y = y <= z
    | otherwise = False

casadecimal :: Percurso -> PercInteresse -> [(Float, Float)]
casadecimal (p1,p2,_,_) (pi1,pi2,_) = [(diminuir p1 c, diminuir p2 c), (pi1,pi2)]
    where 
        c = length (last $ split '.' $ show pi1)


