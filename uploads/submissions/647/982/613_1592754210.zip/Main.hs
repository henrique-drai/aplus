import System.Environment --import para o getArgs
import Calculos
import WriteJson
import Tests
import Test.QuickCheck

main = do
    args <- getArgs
    if head args == "-t" 
    then do 
        quickCheck prop_ganho_pos
        quickCheck prop_join_pi
        quickCheck prop_insert_ganho
    else do
        perc <- readFile (head args) 
        pi <- readFile (args!!1)
        let percursos = percToList perc
        let percpi = piToList pi
        writeFile (last args) (makeJson percursos percpi)