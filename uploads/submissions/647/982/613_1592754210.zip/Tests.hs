module Tests (
    prop_ganho_pos,
    prop_join_pi,
    prop_insert_ganho
) where

import Calculos

prop_ganho_pos :: [Percurso] -> Bool
prop_ganho_pos perc = (ganhoTotal perc) >= 0

prop_join_pi :: [PercInteresse] -> PercInteresse -> Bool
prop_join_pi pi p = length (insert' pi p) == (length pi) + 1

insert' :: [a] -> a -> [a]
insert' [] p = [p]
insert' (x:xs) p = p:x:xs

prop_insert_ganho :: [Percurso] -> Percurso -> Bool
prop_insert_ganho perc p = ganhoTotal (insert' perc p) >= ganhoTotal perc 