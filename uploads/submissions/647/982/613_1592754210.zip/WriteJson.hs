module WriteJson (
    makeJson
) where

import Calculos

makeJson perc piList = "{ \n" ++
    "\t\"Categoria\": " ++ "\"" ++ show categoria_str ++ "\", \n" ++
    "\t\"Tempo total (m)\": " ++ show tempo_total ++ ", \n" ++
    "\t\"Ganho acumulado\": " ++ show ganho_acumulado ++ ", \n" ++
    "\t\"Ganho acumulado por m\": " ++ ganho_metro ++", \n" ++
    "\t\"Pontos de Interesse\": " ++ show pontos_interesse ++" \n}"
    where
        ganho_acumulado = round (ganhoTotal perc)
        ganho_metro = ganhoMetro perc
        categoria_str  = categoria ganho_acumulado (distanciaTotal perc)
        tempo_total = floor $ minutos (head perc) (last perc)
        pontos_interesse = passapor perc piList